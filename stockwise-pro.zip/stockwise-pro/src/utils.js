export function createPageUrl(pageName) {
  const map = {
    Dashboard: "/",
    Products: "/Products",
    POS: "/POS",
    Sales: "/Sales",
    Customers: "/Customers",
    Analytics: "/Analytics",
    Tutorial: "/Tutorial",
    Help: "/Help",
    About: "/About",
    Settings: "/Settings",
    SelfHosting: "/SelfHosting",
  };
  return map[pageName] || `/${pageName}`;
}
