// Base44 SDK client
// See https://docs.base44.com for full documentation
import { createClient } from '@base44/sdk';

export const base44 = createClient({
  appId: import.meta.env.VITE_BASE44_APP_ID,
});
