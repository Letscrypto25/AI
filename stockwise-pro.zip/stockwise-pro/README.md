# StockWise Pro — Self-Hosted Setup

> A full-featured POS & Inventory Management system built on [Base44](https://base44.com).

---

## ✨ Features

- **Point of Sale (POS)** — Fast checkout with product search & cart
- **Inventory Management** — Track stock levels, categories & suppliers
- **Sales History** — Full transaction log with filters & export
- **Customer Management** — Profiles, purchase history & loyalty tracking
- **Analytics Dashboard** — Revenue charts, top products & trends
- **Multi-currency Support** — 20+ currencies supported
- **Dark / Light Mode** — System-aware theme switching
- **Receipt Printing** — Configurable receipt headers & footers

---

## 🚀 Prerequisites

| Tool | Version |
|------|---------|
| Node.js | ≥ 18.x |
| npm | ≥ 9.x |
| Base44 Account | [Sign up free](https://base44.com) |

---

## 📦 Installation

### 1. Extract the zip

Unzip `stockwise-pro.zip` into your desired directory.

```bash
unzip stockwise-pro.zip -d stockwise-pro
cd stockwise-pro
```

Or clone from GitHub:

```bash
git clone https://github.com/your-org/stockwise-pro.git
cd stockwise-pro
```

### 2. Install dependencies

```bash
npm install
```

### 3. Configure environment

```bash
cp .env.example .env
```

Open `.env` and fill in your **Base44 App ID** and **API Key** (found in your Base44 dashboard under Settings → API Keys).

### 4. Run the development server

```bash
npm run dev
```

Visit [http://localhost:5173](http://localhost:5173) — the app is live!

---

## 🏗️ Production Build

```bash
npm run build
```

Serve the `dist/` folder with any static host:

```bash
# Using serve
npx serve dist

# Using nginx — point root to dist/
# Using Vercel/Netlify — drag & drop the dist/ folder
```

---

## 🗂️ Project Structure

```
stockwise-pro/
├── src/
│   ├── pages/          # App pages (Dashboard, POS, Sales …)
│   ├── components/     # Reusable UI components
│   ├── entities/       # Data schemas (Product, Sale, Customer …)
│   ├── lib/            # Auth, utilities
│   ├── Layout.jsx      # App shell & sidebar
│   └── App.jsx         # Router
├── .env.example        # Environment template
├── index.html
├── vite.config.js
└── package.json
```

---

## ⚙️ Configuration

| Variable | Description |
|----------|-------------|
| `VITE_BASE44_APP_ID` | Your Base44 application ID |
| `VITE_BASE44_API_KEY` | Your Base44 API key |
| `VITE_DEFAULT_CURRENCY` | Default store currency code (e.g. `USD`) |
| `VITE_DEFAULT_TAX_RATE` | Default tax percentage |
| `VITE_AUTH_REDIRECT_URL` | Post-login redirect (your domain) |

---

## 🔐 Authentication

Authentication is powered by Base44's built-in auth system. No password storage needed on your server.

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + Vite |
| Styling | Tailwind CSS + shadcn/ui |
| State / Data | TanStack Query + Base44 SDK |
| Charts | Recharts |
| Animations | Framer Motion |
| Backend / DB | Base44 Platform |

---

## 📄 License

MIT © 2026 StockWise Pro
